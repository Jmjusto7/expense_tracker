// src/utils/transactionFilter.js
import { monthIndexOf } from "./dateHelpers";
import { classifyTransaction, matchesBucketAndCategoryFilter } from "./transactionClassification";

// Date-range portion only. Split out because SummaryPage needs this stage
// alone (to compute available categories before bucket/category narrowing).
export function transactionMatchesDate(t, { fromDate, toDate }) {
  if (!t.yearNumber || !t.monthName) return false;

  const txDate = new Date(t.yearNumber, monthIndexOf(t.monthName), 1);

  if (fromDate && txDate < fromDate) return false;
  if (toDate && txDate > toDate) return false;

  return true;
}

// Bucket/Travel + category portion only, assuming date has already passed
// (or isn't being checked).
// Uses native classification: travel-tagged transactions belong to Travel
// bucket exclusively, not their category's normal bucket.
export function transactionMatchesBucketAndCategory(
  t,
  { selectedBucketIds, selectedCategoryFilters, buckets }
) {
  // Classify transaction to get its effective bucket
  const classified = classifyTransaction(t, buckets);

  return matchesBucketAndCategoryFilter(classified, {
    selectedBucketIds,
    selectedCategoryFilters,
  });
}

// Full filter: date range + bucket/Travel + category. This is what every
// page outside SummaryPage should use - one call, matches everything the
// active filter means.
export function transactionMatchesFilter(t, filterState) {
  return (
    transactionMatchesDate(t, filterState) &&
    transactionMatchesBucketAndCategory(t, filterState)
  );
}
