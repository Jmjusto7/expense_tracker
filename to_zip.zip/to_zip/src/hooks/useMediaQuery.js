import { useSyncExternalStore } from "react";

// Tracks a CSS media query; `fallback` is used where matchMedia is unavailable (tests).
export function useMediaQuery(query, fallback = true) {
    return useSyncExternalStore(
        (onChange) => {
            if (typeof window === "undefined" || !window.matchMedia) return () => { };
            const mql = window.matchMedia(query);
            mql.addEventListener("change", onChange);
            return () => mql.removeEventListener("change", onChange);
        },
        () => (typeof window !== "undefined" && window.matchMedia ? window.matchMedia(query).matches : fallback),
        () => fallback
    );
}
